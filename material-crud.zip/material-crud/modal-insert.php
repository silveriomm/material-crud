<!-- Modal Insert -->
<div id="modal-insert" class="modal">
<div class="modal-content">
  <h4>Novo usuário</h4>
    <form action="insert.php" method="post">
        <div class="input-field col s6">
            <label>Nome</label>
            <input id="nome" type="text" name="nome">
        </div>
        <div class="input-field col s6">
            <label>Email</label>
            <input type="text" id="email" name="email">
        </div>
        <div class="input-field col s6">
            <label>Telefone</label>
            <input id="telefone" type="text" name="telefone">
        </div>
        <div class="input-field col s6">
            <label>Cidade</label>
            <input id="cidade" type="text" name="cidade">
        </div>
</div>
<div class="modal-footer">
    <input type="submit" name="save_user" class="modal-close btn" value="Salvar">
<a href="index.php" class="modal-close btn red">Cancelar</a>
</div>
</form>
</div>

