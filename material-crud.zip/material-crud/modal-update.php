<!-- Modal Update -->
<div id="modal-update" class="modal">
<div class="modal-content">
  <h4>Editar usuário</h4>
    <form action="update.php" method="post">
        <div class="input-field col s6">
            <label>Nome</label>
            <input id="unome" type="text" name="unome">
        </div>
        <div class="input-field col s6">
            <label>Email</label>
            <input type="text" id="uemail" name="uemail">
        </div>
        <div class="input-field col s6">
            <label>Telefone</label>
            <input id="utelefone" type="text" name="utelefone">
        </div>
        <div class="input-field col s6">
            <label>Cidade</label>
            <input id="ucidade" type="text" name="ucidade">
        </div>
</div>
<div class="modal-footer">
    <input type="submit" name="update_user" class="modal-close btn" value="Salvar">
<a href="index.php" class="modal-close btn red">Cancelar</a>
<input type="hidden" name="hiddendata" id="hiddendata">
</div>
</form>
</div>

