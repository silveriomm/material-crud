<?php 

$con = new mysqli('localhost', 'root', '', 'material-crud');

if(isset($_GET['delete_id']))
{
    $id = $_GET['delete_id'];

    $sql = "DELETE FROM users WHERE id=$id";

    $res = mysqli_query($con, $sql);

    header("location: index.php");
}

?>
