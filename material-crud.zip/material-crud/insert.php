<?php 

$con = new mysqli('localhost', 'root', '','material-crud');

if(isset($_POST['save_user']))
{
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $telefone = $_POST['telefone'];
    $cidade = $_POST['cidade'];

    $sql = "INSERT INTO users (nome,email,telefone,cidade) VALUES ('$nome', '$email', '$telefone', '$cidade')";

    $res = mysqli_query($con, $sql);

    if($res)
    {
        header("location: index.php");
    }
}

?>
