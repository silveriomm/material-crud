<?php 

// envia os dados para o formulário modal

$con = new mysqli('localhost', 'root', '', 'material-crud');

if(isset($_POST['update_id']))
{
    $id = $_POST['update_id'];

    $sql = "SELECT * FROM users WHERE id=$id";

    $res = mysqli_query($con, $sql);
    $response = array();

    while($row = mysqli_fetch_assoc($res))
    {
        $response = $row;
    }

    echo json_encode($response);
}
else
{
    $response['status'] = 200;
    $response['message'] = "Inválido ou não encontrado.";
}


// atualiza os dados no banco
if(isset($_POST['hiddendata']))
{
    $user_id = $_POST['hiddendata'];
    $nome = $_POST['unome'];
    $email = $_POST['uemail'];
    $telefone = $_POST['utelefone'];
    $cidade = $_POST['ucidade'];

    $sql = "UPDATE users SET nome='$nome', email='$email', telefone='$telefone', cidade='$cidade' WHERE id=$user_id";

    $res = mysqli_query($con, $sql);
    if($res)
    {
        header("location: index.php");
    }
}
?>
