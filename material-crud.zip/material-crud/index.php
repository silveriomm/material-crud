<?php 
include "modal-insert.php";
include "modal-update.php";
include "delete.php";
?>
<!DOCTYPE html>
<html>
<head>
  <!--Import Google Icon Font-->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <!--Import materialize.css-->
  <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>

  <!--Let browser know website is optimized for mobile-->
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Material CRUD</title>
</head>

<body>
<div class="container">
    <h3 class="center-align">Material CRUD</h3>
    <!-- Modal Trigger -->
    <button class="btn-floating blue modal-trigger" data-target="modal-insert"><i class="material-icons">add</i></button>

 <table>
    <thead>
      <tr>
          <th>ID</th>
          <th>Nome</th>
          <th>Email</th>
          <th>Telefone</th>
          <th>Cidade</th>
          <th colspan="2"></th>
      </tr>
    </thead>

    <tbody>
    <?php 
        $con = new mysqli('localhost', 'root', '', 'material-crud');
        $sql = "SELECT * FROM users";
        $res = mysqli_query($con, $sql);
        while($row = mysqli_fetch_assoc($res))
        {
    ?>
      <tr>
      <td><?= $row['id'] ?></td>
      <td><?= $row['nome'] ?></td>
      <td><?= $row['email'] ?></td>
      <td><?= $row['telefone'] ?></td>
      <td><?= $row['cidade'] ?></td>
      <td>
      <button onclick="updateUser(<?= $row['id'] ?>)" class="btn-floating orange modal-trigger" data-target="modal-update"><i class="material-icons">edit</i></button>
      </td>
      <td>
      <a href="?delete_id=<?= $row['id'] ?>" class="btn-floating red"><i class="material-icons">delete</i></a>
      </td>
      </tr>
      <tr>
    <?php } ?>
    </tbody>
  </table>

</div>

  <!--JavaScript at end of body for optimized loading-->
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script type="text/javascript" src="js/materialize.min.js"></script>
    <script type="text/javascript" src="js/modal.js"></script>
</body>

<script>
// envia os dados para o formulário modal
function updateUser(update_id) {
    $('#hiddendata').val(update_id);

    $.post("update.php", {update_id:update_id}, function(data, status) {
        var user_id = JSON.parse(data);
        $('#unome').val(user_id.nome);
        $('#uemail').val(user_id.email);
        $('#utelefone').val(user_id.telefone);
        $('#ucidade').val(user_id.cidade);
    });

    // $('#modal-update').modal("show");    
}

// atualiza os dados no banco
function updateUserSubmit() {
    var nome = $('#unome').val();
    var email = $('#email').val();
    var telefone = $('#telefone').val();
    var cidade = $('#cidade').val();
    var hiddendata = $('#hiddendata').val();

    $.post("update.php", {
        nome: nome,
        email: email,
        telefone: telfone,
        cidade: cidade,
        hiddendata: hiddendata
    }, function(data, status){
        $('#modal-update').modal('hide');
    });
}
</script>

</html>
